#include <Arduino.h>

int counts = 0; 
int lastCount = 0; 

long unsigned int lastCountMs = 0; 


void increaseCount()
{
        if ((millis() - lastCountMs) > 5){
                counts++; 
                lastCountMs = millis(); 
        }
}

void setup()
{
        pinMode(13, OUTPUT);
        pinMode(23, INPUT); 
        Serial.begin(9600); 
        digitalWrite(13, HIGH);
        delay(1000); 
        attachInterrupt(digitalPinToInterrupt(23), increaseCount, RISING); 
        Serial.println(lastCount); 
        digitalWrite(13, LOW); 
}

void loop()
{
        if (counts > lastCount) {
                digitalWrite(13, HIGH); 
                lastCount = counts;
                Serial.println(lastCount); 
                delay(25); 
                digitalWrite(13, LOW); 
        }
}

